
import React, { useState } from 'react';

interface User {
  name: string;
  email: string;
}

interface LayoutProps {
  children: React.ReactNode;
  user: User | null;
  onSignInClick: () => void;
  onSignOut: () => void;
}

const Layout: React.FC<LayoutProps> = ({ children, user, onSignInClick, onSignOut }) => {
  const [showUserMenu, setShowUserMenu] = useState(false);

  return (
    <div className="min-h-screen flex flex-col">
      <header className="sticky top-0 z-50 glass-morphism border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center space-x-2 cursor-pointer" onClick={() => window.location.hash = ''}>
            <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center text-white shadow-lg shadow-indigo-200">
              <i className="fa-solid fa-book-open text-lg"></i>
            </div>
            <span className="text-xl font-bold tracking-tight text-slate-900 font-serif">Sabah Library</span>
          </div>
          
          <div className="flex items-center space-x-4">
             {/* Search button removed from here */}
             
             {user ? (
               <div className="relative">
                 <button 
                  onClick={() => setShowUserMenu(!showUserMenu)}
                  className="flex items-center space-x-2 p-1 pr-3 bg-slate-100 hover:bg-slate-200 rounded-full transition-colors"
                 >
                   <div className="w-8 h-8 bg-indigo-600 rounded-full flex items-center justify-center text-white text-xs font-bold">
                     {user.name.charAt(0).toUpperCase()}
                   </div>
                   <span className="text-sm font-semibold text-slate-700 hidden sm:block">{user.name}</span>
                   <i className={`fa-solid fa-chevron-down text-[10px] text-slate-400 transition-transform ${showUserMenu ? 'rotate-180' : ''}`}></i>
                 </button>

                 {showUserMenu && (
                   <>
                     <div className="fixed inset-0 z-40" onClick={() => setShowUserMenu(false)}></div>
                     <div className="absolute right-0 mt-2 w-48 bg-white rounded-2xl shadow-2xl border border-slate-100 py-2 z-50 animate-in fade-in slide-in-from-top-2 duration-200">
                       <div className="px-4 py-2 border-b border-slate-50 mb-1">
                         <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">Signed in as</p>
                         <p className="text-sm font-bold text-slate-900 truncate">{user.email}</p>
                       </div>
                       <button className="w-full text-left px-4 py-2 text-sm text-slate-600 hover:bg-slate-50 hover:text-indigo-600 flex items-center space-x-2">
                         <i className="fa-solid fa-user-gear"></i>
                         <span>Settings</span>
                       </button>
                       <button className="w-full text-left px-4 py-2 text-sm text-slate-600 hover:bg-slate-50 hover:text-indigo-600 flex items-center space-x-2">
                         <i className="fa-solid fa-bookmark"></i>
                         <span>My Lists</span>
                       </button>
                       <button 
                        onClick={() => { onSignOut(); setShowUserMenu(false); }}
                        className="w-full text-left px-4 py-2 text-sm text-rose-600 hover:bg-rose-50 flex items-center space-x-2 border-t border-slate-50 mt-1"
                       >
                         <i className="fa-solid fa-right-from-bracket"></i>
                         <span>Sign Out</span>
                       </button>
                     </div>
                   </>
                 )}
               </div>
             ) : (
               <button 
                onClick={onSignInClick}
                className="hidden sm:block px-6 py-2 bg-indigo-600 text-white rounded-lg text-sm font-semibold hover:bg-indigo-700 transition-all shadow-md shadow-indigo-100"
               >
                 Sign In
               </button>
             )}
          </div>
        </div>
      </header>

      <main className="flex-grow">
        {children}
      </main>

      <footer className="bg-slate-900 text-slate-400 py-12">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <div className="font-serif text-2xl text-white mb-4">Sabah Library</div>
          <p className="max-w-md mx-auto mb-8">
            Powered by Open Library and Gemini AI. Exploring the world's knowledge, one page at a time.
          </p>
          <div className="flex justify-center space-x-6 mb-8">
            <a href="#" className="hover:text-white transition-colors"><i className="fa-brands fa-twitter text-xl"></i></a>
            <a href="#" className="hover:text-white transition-colors"><i className="fa-brands fa-github text-xl"></i></a>
            <a href="#" className="hover:text-white transition-colors"><i className="fa-brands fa-discord text-xl"></i></a>
          </div>
          <p className="text-xs uppercase tracking-widest">© 2024 Sabah Library. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
};

export default Layout;
