
import React, { useEffect, useState } from 'react';
import { BookDetails, Book } from '../types';
import { getBookDetails, getCoverUrl } from '../services/openLibrary';
import { getBookInsights } from '../services/gemini';

interface BookDetailModalProps {
  bookKey: string;
  initialData?: Book;
  onClose: () => void;
  isFavorite: boolean;
  isRead: boolean;
  onToggleFavorite: (e: React.MouseEvent, book: Book) => void;
  onToggleRead: (e: React.MouseEvent, book: Book) => void;
}

const BookDetailModal: React.FC<BookDetailModalProps> = ({ 
  bookKey, 
  initialData, 
  onClose, 
  isFavorite, 
  isRead,
  onToggleFavorite,
  onToggleRead
}) => {
  const [details, setDetails] = useState<BookDetails | null>(null);
  const [loadingDetails, setLoadingDetails] = useState(true);
  const [aiInsights, setAiInsights] = useState<{ summary: string, themes: string[] } | null>(null);
  const [loadingAi, setLoadingAi] = useState(false);

  useEffect(() => {
    // Reset states for new book
    setDetails(null);
    setAiInsights(null);
    
    const fetchAll = async () => {
      setLoadingDetails(true);
      setLoadingAi(true);

      // Start both requests in parallel
      const detailsPromise = getBookDetails(bookKey);
      const aiPromise = getBookInsights(
        initialData?.title || 'Unknown Title', 
        initialData?.author_name?.[0] || 'Unknown Author'
      );

      // Handle details as soon as they arrive
      detailsPromise.then(data => {
        setDetails(data);
        setLoadingDetails(false);
      }).catch(err => {
        console.error("Details Fetch Error:", err);
        setLoadingDetails(false);
      });

      // Handle AI insights independently
      aiPromise.then(insights => {
        setAiInsights(insights);
        setLoadingAi(false);
      }).catch(err => {
        console.error("AI Insights Error:", err);
        setLoadingAi(false);
      });
    };

    fetchAll();
  }, [bookKey, initialData]);

  // Use initial data as fallback to show UI immediately
  const displayTitle = details?.title || initialData?.title || 'Loading Title...';
  const displayAuthors = initialData?.author_name?.join(', ') || 'Loading Authors...';
  const displayCoverId = details?.covers?.[0] || initialData?.cover_i;
  
  const description = typeof details?.description === 'string' 
    ? details.description 
    : details?.description?.value;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 sm:p-6 md:p-12 overflow-hidden">
      <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm" onClick={onClose}></div>
      <div className="bg-white w-full max-w-5xl max-h-full rounded-3xl shadow-2xl relative overflow-hidden flex flex-col md:flex-row animate-in fade-in zoom-in duration-300">
        <button 
          onClick={onClose}
          className="absolute top-4 right-4 z-20 w-10 h-10 bg-white/80 backdrop-blur-md shadow-md rounded-full flex items-center justify-center hover:bg-white text-slate-500 transition-colors"
        >
          <i className="fa-solid fa-xmark"></i>
        </button>

        {/* Left Side: Cover (Instantly Visible) */}
        <div className="w-full md:w-1/3 bg-slate-100 p-8 flex items-center justify-center relative">
          <img 
            src={getCoverUrl(displayCoverId, 'L')} 
            alt={displayTitle}
            className="w-full max-w-[280px] shadow-2xl rounded-lg transform -rotate-1 hover:rotate-0 transition-transform duration-500"
          />
          {isRead && (
            <div className="absolute top-4 left-4 bg-emerald-500 text-white px-3 py-1 rounded-full text-xs font-bold shadow-lg flex items-center">
              <i className="fa-solid fa-circle-check mr-2"></i> Finished
            </div>
          )}
        </div>
        
        {/* Right Side: Details (Partially Instantly Visible) */}
        <div className="w-full md:w-2/3 p-8 md:p-12 overflow-y-auto">
          <div className="mb-8">
            <h2 className="text-4xl font-serif font-bold text-slate-900 mb-2">{displayTitle}</h2>
            <p className="text-lg text-slate-500 italic">By {displayAuthors}</p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="space-y-6">
              <div>
                <h4 className="text-xs font-bold uppercase tracking-widest text-slate-400 mb-3">Library Description</h4>
                {loadingDetails ? (
                  <div className="space-y-2 animate-pulse">
                    <div className="h-3 bg-slate-100 rounded w-full"></div>
                    <div className="h-3 bg-slate-100 rounded w-5/6"></div>
                    <div className="h-3 bg-slate-100 rounded w-4/6"></div>
                  </div>
                ) : (
                  <p className="text-slate-600 leading-relaxed text-sm">
                    {description || 'No official description available in the Open Library catalog.'}
                  </p>
                )}
              </div>
              
              {details?.subjects && (
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-widest text-slate-400 mb-3">Subjects</h4>
                  <div className="flex flex-wrap gap-2">
                    {details.subjects.slice(0, 8).map(s => (
                      <span key={s} className="px-3 py-1 bg-slate-100 text-slate-600 rounded-full text-xs font-medium">
                        {s}
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </div>

            <div className="space-y-6">
              {/* AI Section (Decoupled Loading) */}
              <div className="bg-indigo-50 border border-indigo-100 p-6 rounded-2xl relative">
                <div className="absolute top-4 right-4 text-indigo-300">
                  <i className="fa-solid fa-robot text-xl"></i>
                </div>
                <h4 className="text-xs font-bold uppercase tracking-widest text-indigo-500 mb-3">AI Quick Insight</h4>
                {loadingAi ? (
                  <div className="space-y-3">
                    <div className="flex items-center space-x-2 text-indigo-400 mb-2">
                      <i className="fa-solid fa-circle-notch fa-spin text-xs"></i>
                      <span className="text-[10px] font-bold uppercase tracking-tighter">Synthesizing...</span>
                    </div>
                    <div className="h-3 bg-indigo-100/50 rounded w-full animate-pulse"></div>
                    <div className="h-3 bg-indigo-100/50 rounded w-4/5 animate-pulse"></div>
                  </div>
                ) : aiInsights ? (
                  <div className="space-y-4">
                    <p className="text-indigo-900 text-sm leading-relaxed italic">
                      "{aiInsights.summary}"
                    </p>
                    <div className="flex flex-wrap gap-2">
                      {aiInsights.themes.map(theme => (
                        <span key={theme} className="text-[10px] font-bold text-indigo-500 bg-white border border-indigo-200 px-2 py-0.5 rounded uppercase">
                          #{theme}
                        </span>
                      ))}
                    </div>
                  </div>
                ) : (
                  <p className="text-xs text-indigo-400 italic">AI insights currently unavailable for this title.</p>
                )}
              </div>

              {/* Action Buttons (Instantly Interactive) */}
              <div className="flex flex-wrap gap-3">
                <a 
                  href={`https://openlibrary.org${bookKey}`} 
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-grow min-w-[150px] bg-indigo-600 text-white text-center py-3 rounded-xl font-bold hover:bg-indigo-700 transition-colors shadow-lg"
                >
                  Read Online
                </a>
                <div className="flex gap-2">
                  <button 
                    onClick={(e) => initialData && onToggleFavorite(e, initialData)}
                    title={isFavorite ? "Remove from favorites" : "Add to favorites"}
                    className={`w-12 h-12 flex items-center justify-center border rounded-xl transition-all ${
                      isFavorite ? 'bg-rose-50 border-rose-200 text-rose-500' : 'border-slate-200 text-slate-400 hover:text-rose-500 hover:bg-rose-50'
                    }`}
                  >
                    <i className={`${isFavorite ? 'fa-solid' : 'fa-regular'} fa-heart text-xl`}></i>
                  </button>
                  <button 
                    onClick={(e) => initialData && onToggleRead(e, initialData)}
                    title={isRead ? "Mark as unread" : "Mark as read"}
                    className={`w-12 h-12 flex items-center justify-center border rounded-xl transition-all ${
                      isRead ? 'bg-emerald-50 border-emerald-200 text-emerald-500' : 'border-slate-200 text-slate-400 hover:text-emerald-500 hover:bg-emerald-50'
                    }`}
                  >
                    <i className={`fa-solid ${isRead ? 'fa-check-circle' : 'fa-check'} text-xl`}></i>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BookDetailModal;
