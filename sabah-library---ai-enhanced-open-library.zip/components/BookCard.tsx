
import React from 'react';
import { Book } from '../types';
import { getCoverUrl } from '../services/openLibrary';

interface BookCardProps {
  book: Book;
  onClick: (key: string) => void;
  isFavorite: boolean;
  isRead: boolean;
  onToggleFavorite: (e: React.MouseEvent, book: Book) => void;
  onToggleRead: (e: React.MouseEvent, book: Book) => void;
}

const BookCard: React.FC<BookCardProps> = ({ 
  book, 
  onClick, 
  isFavorite, 
  isRead, 
  onToggleFavorite,
  onToggleRead
}) => {
  return (
    <div 
      className="group bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 border border-slate-100 cursor-pointer flex flex-col h-full relative"
      onClick={() => onClick(book.key)}
    >
      <div className="absolute top-3 right-3 z-10 flex flex-col gap-2">
        <button 
          onClick={(e) => onToggleFavorite(e, book)}
          title={isFavorite ? "Remove from favorites" : "Add to favorites"}
          className={`w-9 h-9 rounded-full flex items-center justify-center backdrop-blur-md transition-all ${
            isFavorite ? 'bg-rose-500 text-white' : 'bg-white/70 text-slate-400 hover:text-rose-500'
          } shadow-sm`}
        >
          <i className={`${isFavorite ? 'fa-solid' : 'fa-regular'} fa-heart`}></i>
        </button>
        <button 
          onClick={(e) => onToggleRead(e, book)}
          title={isRead ? "Mark as unread" : "Mark as read"}
          className={`w-9 h-9 rounded-full flex items-center justify-center backdrop-blur-md transition-all ${
            isRead ? 'bg-emerald-500 text-white' : 'bg-white/70 text-slate-400 hover:text-emerald-500'
          } shadow-sm`}
        >
          <i className={`fa-solid ${isRead ? 'fa-check-circle' : 'fa-check'}`}></i>
        </button>
      </div>

      <div className="aspect-[2/3] overflow-hidden relative">
        <img 
          src={getCoverUrl(book.cover_i, 'M')} 
          alt={book.title}
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
          loading="lazy"
        />
        {isRead && (
          <div className="absolute inset-0 bg-emerald-500/10 pointer-events-none"></div>
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-4">
          <span className="text-white text-sm font-medium">View Details</span>
        </div>
        {book.first_publish_year && (
          <div className="absolute top-3 left-3 bg-white/90 backdrop-blur px-2 py-1 rounded text-[10px] font-bold text-slate-700 shadow-sm uppercase tracking-wider">
            {book.first_publish_year}
          </div>
        )}
      </div>
      <div className="p-4 flex-grow flex flex-col">
        <h3 className="font-bold text-slate-800 line-clamp-2 leading-tight group-hover:text-indigo-600 transition-colors mb-1">
          {book.title}
        </h3>
        <p className="text-sm text-slate-500 line-clamp-1 mb-3 italic">
          {book.author_name?.join(', ') || 'Unknown Author'}
        </p>
        <div className="mt-auto pt-3 border-t border-slate-50 flex items-center justify-between text-[11px] font-semibold text-slate-400">
           <span className="flex items-center">
             <i className="fa-solid fa-copy mr-1 text-indigo-400"></i>
             {book.edition_count || 1} Editions
           </span>
           {isRead && (
             <span className="flex items-center text-emerald-500">
               <i className="fa-solid fa-circle-check mr-1"></i>
               Read
             </span>
           )}
        </div>
      </div>
    </div>
  );
};

export default BookCard;
