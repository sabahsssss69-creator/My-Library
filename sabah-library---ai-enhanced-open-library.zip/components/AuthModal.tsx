
import React, { useState } from 'react';

interface AuthModalProps {
  onClose: () => void;
  onLogin: (user: { name: string; email: string; photo?: string }) => void;
}

const AuthModal: React.FC<AuthModalProps> = ({ onClose, onLogin }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [isGoogleLoading, setIsGoogleLoading] = useState(false);
  const [showGoogleSelector, setShowGoogleSelector] = useState(false);
  const [isAddingAccount, setIsAddingAccount] = useState(false);

  // For "Add another account" form
  const [newAccName, setNewAccName] = useState('');
  const [newAccEmail, setNewAccEmail] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate manual authentication
    onLogin({ name: name || email.split('@')[0], email });
    onClose();
  };

  const handleGoogleSignIn = () => {
    setIsGoogleLoading(true);
    // Simulate the time it takes for a popup to initialize
    setTimeout(() => {
      setIsGoogleLoading(false);
      setShowGoogleSelector(true);
      setIsAddingAccount(false);
    }, 800);
  };

  const selectGoogleAccount = (accountName: string, accountEmail: string) => {
    setIsGoogleLoading(true);
    setShowGoogleSelector(false);
    setIsAddingAccount(false);
    // Simulate the handshake/validation
    setTimeout(() => {
      onLogin({ 
        name: accountName, 
        email: accountEmail,
        photo: `https://ui-avatars.com/api/?name=${encodeURIComponent(accountName)}&background=4f46e5&color=fff`
      });
      setIsGoogleLoading(false);
      onClose();
    }, 1200);
  };

  const handleAddNewAccount = (e: React.FormEvent) => {
    e.preventDefault();
    if (newAccName && newAccEmail) {
      selectGoogleAccount(newAccName, newAccEmail);
    }
  };

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-slate-900/40 backdrop-blur-md" onClick={onClose}></div>
      
      {showGoogleSelector ? (
        <div className="bg-white w-full max-w-sm rounded-3xl shadow-2xl relative overflow-hidden animate-in fade-in zoom-in duration-300">
          <div className="p-8 text-center border-b border-slate-50">
            <img src="https://upload.wikimedia.org/wikipedia/commons/5/53/Google_HiRes_Logo.png" alt="Google" className="h-6 mx-auto mb-4" />
            <h3 className="text-xl font-bold text-slate-800">
              {isAddingAccount ? 'Add an account' : 'Choose an account'}
            </h3>
            <p className="text-sm text-slate-500">to continue to Sabah Library</p>
          </div>
          
          <div className="p-2 max-h-[400px] overflow-y-auto">
            {!isAddingAccount ? (
              <>
                {[
                  { name: 'Alex Reader', email: 'alex.reader@gmail.com' },
                  { name: 'Sam Librarian', email: 'sam.lib@gmail.com' }
                ].map((acc) => (
                  <button 
                    key={acc.email}
                    onClick={() => selectGoogleAccount(acc.name, acc.email)}
                    className="w-full flex items-center p-4 hover:bg-slate-50 transition-colors text-left border-b border-slate-50 last:border-0"
                  >
                    <div className="w-10 h-10 rounded-full bg-slate-200 flex items-center justify-center text-slate-600 font-bold mr-4">
                      {acc.name.charAt(0)}
                    </div>
                    <div className="flex-grow">
                      <div className="text-sm font-bold text-slate-900">{acc.name}</div>
                      <div className="text-xs text-slate-500">{acc.email}</div>
                    </div>
                    <i className="fa-solid fa-chevron-right text-slate-300 text-xs"></i>
                  </button>
                ))}
                <button 
                  onClick={() => setIsAddingAccount(true)}
                  className="w-full flex items-center p-4 hover:bg-slate-50 transition-colors text-left text-indigo-600 font-bold text-sm"
                >
                  <i className="fa-solid fa-circle-plus mr-4"></i>
                  Use another account
                </button>
              </>
            ) : (
              <form onSubmit={handleAddNewAccount} className="p-4 space-y-4">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-400 uppercase">Full Name</label>
                  <input 
                    type="text" 
                    required
                    autoFocus
                    value={newAccName}
                    onChange={(e) => setNewAccName(e.target.value)}
                    placeholder="Enter your name"
                    className="w-full px-4 py-2 bg-slate-50 border border-slate-100 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-400 transition-all text-sm"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-400 uppercase">Email</label>
                  <input 
                    type="email" 
                    required
                    value={newAccEmail}
                    onChange={(e) => setNewAccEmail(e.target.value)}
                    placeholder="name@gmail.com"
                    className="w-full px-4 py-2 bg-slate-50 border border-slate-100 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-400 transition-all text-sm"
                  />
                </div>
                <div className="flex gap-2 pt-2">
                  <button 
                    type="button"
                    onClick={() => setIsAddingAccount(false)}
                    className="flex-1 py-2 text-sm font-bold text-slate-500 hover:bg-slate-50 rounded-lg transition-colors"
                  >
                    Back
                  </button>
                  <button 
                    type="submit"
                    className="flex-1 py-2 text-sm font-bold bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors shadow-md"
                  >
                    Continue
                  </button>
                </div>
              </form>
            )}
          </div>
          <div className="p-6 bg-slate-50 text-[10px] text-slate-400 text-center leading-relaxed">
            To continue, Google will share your name, email address, language preference, and profile picture with Sabah Library.
          </div>
        </div>
      ) : (
        <div className="bg-white w-full max-w-md rounded-3xl shadow-2xl relative overflow-hidden animate-in fade-in zoom-in duration-300">
          {isGoogleLoading && (
            <div className="absolute inset-0 bg-white/80 backdrop-blur-[2px] z-50 flex flex-col items-center justify-center">
              <div className="w-12 h-12 border-4 border-indigo-100 border-t-indigo-600 rounded-full animate-spin mb-4"></div>
              <p className="text-indigo-600 font-bold">Connecting to Google...</p>
            </div>
          )}
          
          <div className="bg-indigo-600 p-8 text-center text-white relative">
            <button 
              onClick={onClose}
              className="absolute top-4 right-4 text-white/70 hover:text-white transition-colors"
            >
              <i className="fa-solid fa-xmark"></i>
            </button>
            <div className="w-16 h-16 bg-white/20 rounded-2xl flex items-center justify-center mx-auto mb-4 backdrop-blur-sm">
              <i className="fa-solid fa-book-open text-2xl"></i>
            </div>
            <h2 className="text-2xl font-serif font-bold">{isLogin ? 'Welcome Back' : 'Create Account'}</h2>
            <p className="text-indigo-100 text-sm mt-2">Access your personal library from any device.</p>
          </div>

          <form onSubmit={handleSubmit} className="p-8 space-y-4">
            {!isLogin && (
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-400 uppercase tracking-widest ml-1">Full Name</label>
                <div className="relative">
                  <input 
                    type="text" 
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="John Doe"
                    className="w-full pl-11 pr-4 py-3 bg-slate-50 border border-slate-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-400 transition-all"
                  />
                  <i className="fa-solid fa-user absolute left-4 top-1/2 -translate-y-1/2 text-slate-300"></i>
                </div>
              </div>
            )}

            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-400 uppercase tracking-widest ml-1">Email Address</label>
              <div className="relative">
                <input 
                  type="email" 
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="hello@example.com"
                  className="w-full pl-11 pr-4 py-3 bg-slate-50 border border-slate-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-400 transition-all"
                />
                <i className="fa-solid fa-envelope absolute left-4 top-1/2 -translate-y-1/2 text-slate-300"></i>
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-400 uppercase tracking-widest ml-1">Password</label>
              <div className="relative">
                <input 
                  type="password" 
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full pl-11 pr-4 py-3 bg-slate-50 border border-slate-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-400 transition-all"
                />
                <i className="fa-solid fa-lock absolute left-4 top-1/2 -translate-y-1/2 text-slate-300"></i>
              </div>
            </div>

            {isLogin && (
              <div className="text-right">
                <button type="button" className="text-xs font-bold text-indigo-600 hover:underline">Forgot Password?</button>
              </div>
            )}

            <button 
              type="submit"
              className="w-full bg-indigo-600 text-white py-4 rounded-xl font-bold shadow-lg shadow-indigo-200 hover:bg-indigo-700 transition-all mt-4"
            >
              {isLogin ? 'Sign In' : 'Create Account'}
            </button>

            <div className="relative py-4">
              <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-slate-100"></div></div>
              <div className="relative flex justify-center text-xs uppercase"><span className="bg-white px-2 text-slate-400 font-bold">Or continue with</span></div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <button 
                type="button" 
                onClick={handleGoogleSignIn}
                className="flex items-center justify-center space-x-2 py-3 border border-slate-100 rounded-xl hover:bg-slate-50 transition-colors"
              >
                <i className="fa-brands fa-google text-slate-400"></i>
                <span className="text-sm font-bold text-slate-600">Google</span>
              </button>
              <button type="button" className="flex items-center justify-center space-x-2 py-3 border border-slate-100 rounded-xl hover:bg-slate-50 transition-colors">
                <i className="fa-brands fa-apple text-slate-400"></i>
                <span className="text-sm font-bold text-slate-600">Apple</span>
              </button>
            </div>

            <p className="text-center text-sm text-slate-500 mt-6">
              {isLogin ? "Don't have an account?" : "Already have an account?"}{' '}
              <button 
                type="button" 
                onClick={() => setIsLogin(!isLogin)}
                className="text-indigo-600 font-bold hover:underline"
              >
                {isLogin ? 'Sign Up' : 'Log In'}
              </button>
            </p>
          </form>
        </div>
      )}
    </div>
  );
};

export default AuthModal;
