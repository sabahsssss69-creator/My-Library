
import React, { useState } from 'react';
import { getRecommendations } from '../services/gemini';

const RecommendationSection: React.FC = () => {
  const [prompt, setPrompt] = useState('');
  const [loading, setLoading] = useState(false);
  const [recommendations, setRecommendations] = useState<any[]>([]);

  const handleRecommend = async () => {
    if (!prompt.trim()) return;
    setLoading(true);
    const results = await getRecommendations(prompt);
    setRecommendations(results);
    setLoading(false);
  };

  return (
    <section id="recommendations" className="py-20 bg-indigo-900 text-white rounded-3xl mx-4 sm:mx-8 px-6 sm:px-12 relative overflow-hidden my-12">
      <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500/20 rounded-full blur-3xl -mr-32 -mt-32"></div>
      <div className="absolute bottom-0 left-0 w-64 h-64 bg-purple-500/20 rounded-full blur-3xl -ml-32 -mb-32"></div>
      
      <div className="relative z-10 max-w-4xl mx-auto text-center">
        <div className="inline-flex items-center space-x-2 bg-indigo-500/30 px-4 py-1.5 rounded-full text-indigo-200 text-sm font-semibold mb-6">
          <i className="fa-solid fa-wand-magic-sparkles"></i>
          <span>AI Reading Assistant</span>
        </div>
        <h2 className="text-3xl sm:text-4xl font-serif font-bold mb-6">What should you read next?</h2>
        <p className="text-indigo-200 mb-10 text-lg">Tell us what topics or genres you enjoy, and our Gemini-powered engine will suggest your next favorite book.</p>
        
        <div className="flex flex-col sm:flex-row gap-3">
          <input 
            type="text"
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="e.g. Space exploration, deep philosophy, or 19th-century romance..."
            className="flex-grow px-6 py-4 rounded-xl bg-white/10 border border-white/20 text-white placeholder:text-white/40 focus:outline-none focus:ring-2 focus:ring-indigo-400 transition-all text-lg"
          />
          <button 
            onClick={handleRecommend}
            disabled={loading}
            className="px-8 py-4 bg-white text-indigo-900 rounded-xl font-bold hover:bg-indigo-50 transition-colors shadow-lg flex items-center justify-center min-w-[160px]"
          >
            {loading ? <i className="fa-solid fa-circle-notch fa-spin mr-2"></i> : null}
            {loading ? 'Thinking...' : 'Get Suggests'}
          </button>
        </div>

        {recommendations.length > 0 && (
          <div className="mt-16 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 text-left">
            {recommendations.map((rec, idx) => (
              <div key={idx} className="bg-white/10 backdrop-blur-sm border border-white/10 p-6 rounded-2xl hover:bg-white/15 transition-all">
                <h4 className="font-bold text-xl mb-1">{rec.title}</h4>
                <p className="text-indigo-300 text-sm mb-4">by {rec.author}</p>
                <p className="text-white/80 text-sm italic">"{rec.reason}"</p>
              </div>
            ))}
          </div>
        )}
      </div>
    </section>
  );
};

export default RecommendationSection;
