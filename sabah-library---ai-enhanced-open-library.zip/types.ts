
export interface Book {
  key: string;
  title: string;
  author_name?: string[];
  first_publish_year?: number;
  cover_i?: number;
  isbn?: string[];
  subject?: string[];
  edition_count?: number;
}

export interface Author {
  key: string;
  name: string;
  birth_date?: string;
  top_work?: string;
  work_count?: number;
}

export interface BookDetails {
  key: string;
  title: string;
  description?: string | { value: string };
  covers?: number[];
  subjects?: string[];
  created?: { value: string };
}

export interface AuthorDetails {
  name: string;
  bio?: string | { value: string };
  birth_date?: string;
  death_date?: string;
  photos?: number[];
}
