
import { Book, Author, BookDetails, AuthorDetails } from '../types';

const BASE_URL = 'https://openlibrary.org';

const fetchWithRetry = async (url: string, retries: number = 2): Promise<Response> => {
  try {
    const response = await fetch(url);
    if (!response.ok) {
      if (response.status === 429 && retries > 0) {
        await new Promise(resolve => setTimeout(resolve, 2000));
        return fetchWithRetry(url, retries - 1);
      }
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    return response;
  } catch (e) {
    if (retries > 0) {
      await new Promise(resolve => setTimeout(resolve, 1500));
      return fetchWithRetry(url, retries - 1);
    }
    throw e;
  }
};

export const searchBooks = async (query: string, page: number = 1): Promise<{ docs: Book[], numFound: number }> => {
  const fields = 'key,title,author_name,first_publish_year,cover_i,edition_count';
  const response = await fetchWithRetry(`${BASE_URL}/search.json?q=${encodeURIComponent(query)}&page=${page}&limit=20&fields=${fields}`);
  const data = await response.json();
  return {
    docs: data.docs || [],
    numFound: data.num_found ?? data.numFound ?? 0
  };
};

export const fetchSuggestions = async (query: string): Promise<Book[]> => {
  if (!query || query.length < 3) return [];
  const fields = 'key,title,author_name,cover_i';
  try {
    const response = await fetch(`${BASE_URL}/search.json?q=${encodeURIComponent(query)}&limit=8&fields=${fields}`);
    if (!response.ok) return [];
    const data = await response.json();
    return data.docs || [];
  } catch (e) {
    return [];
  }
};

export const getBookDetails = async (workId: string): Promise<BookDetails> => {
  const response = await fetchWithRetry(`${BASE_URL}${workId}.json`);
  return response.json();
};

export const getAuthorDetails = async (authorId: string): Promise<AuthorDetails> => {
  const id = authorId.replace('/authors/', '');
  const response = await fetchWithRetry(`${BASE_URL}/authors/${id}.json`);
  return response.json();
};

export const getCoverUrl = (coverId?: number, size: 'S' | 'M' | 'L' = 'M') => {
  if (!coverId) return 'https://via.placeholder.com/300x450?text=No+Cover';
  return `https://covers.openlibrary.org/b/id/${coverId}-${size}.jpg`;
};

export const getAuthorPhotoUrl = (photoId?: number, size: 'S' | 'M' | 'L' = 'M') => {
  if (!photoId) return 'https://via.placeholder.com/300x300?text=No+Photo';
  return `https://covers.openlibrary.org/a/id/${photoId}-${size}.jpg`;
};
