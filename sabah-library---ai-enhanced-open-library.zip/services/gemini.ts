
import { GoogleGenAI, Type } from "@google/genai";

// Initialize the Google GenAI client with the API key from environment variables
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

// Fetches a compelling summary and key themes for a specific book title and author using Gemini 3 Flash
export const getBookInsights = async (title: string, author: string) => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Provide a compelling 3-sentence summary and 3 key themes for the book "${title}" by ${author}. Format the output as JSON.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            summary: { type: Type.STRING },
            themes: { 
              type: Type.ARRAY,
              items: { type: Type.STRING }
            }
          },
          required: ["summary", "themes"]
        }
      }
    });
    // Accessing the text property directly as per Gemini API guidelines
    const text = response.text;
    return text ? JSON.parse(text) : null;
  } catch (error) {
    console.error("Gemini Insight Error:", error);
    return null;
  }
};

/**
 * FIX: Added missing exported function getRecommendations.
 * This function recommends books based on a user prompt using Gemini 3 Flash.
 */
export const getRecommendations = async (prompt: string) => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Based on the following interest or request: "${prompt}", recommend 3 books that would be a great fit. For each book, provide the title, author, and a concise reason for the recommendation. Format the response as a JSON array.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              author: { type: Type.STRING },
              reason: { type: Type.STRING }
            },
            required: ["title", "author", "reason"]
          }
        }
      }
    });
    // Accessing the text property directly
    const text = response.text;
    return text ? JSON.parse(text) : [];
  } catch (error) {
    console.error("Gemini Recommendation Error:", error);
    return [];
  }
};
