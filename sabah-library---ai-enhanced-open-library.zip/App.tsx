
import React, { useState, useEffect, useCallback, useRef } from 'react';
import Layout from './components/Layout';
import BookCard from './components/BookCard';
import BookDetailModal from './components/BookDetailModal';
import AuthModal from './components/AuthModal';
import RecommendationSection from './components/RecommendationSection';
import { Book } from './types';
import { searchBooks, fetchSuggestions, getCoverUrl } from './services/openLibrary';

const CATEGORIES = [
  { id: 'sci_fi', label: 'Science Fiction', icon: 'fa-rocket', query: 'subject:science_fiction' },
  { id: 'fantasy', label: 'Fantasy', icon: 'fa-dragon', query: 'subject:fantasy' },
  { id: 'romance', label: 'Romance', icon: 'fa-heart', query: 'subject:romance' },
  { id: 'mystery', label: 'Mystery & Thriller', icon: 'fa-user-secret', query: 'subject:mystery' },
  { id: 'history', label: 'History', icon: 'fa-landmark', query: 'subject:history' },
];

const App: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState<string | null>(null);
  const [books, setBooks] = useState<Book[]>([]);
  const [loading, setLoading] = useState(false);
  const [selectedBookKey, setSelectedBookKey] = useState<string | null>(null);
  const [page, setPage] = useState(1);
  const [totalFound, setTotalFound] = useState(0);
  
  // Autocomplete state
  const [suggestions, setSuggestions] = useState<Book[]>([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [isSuggesting, setIsSuggesting] = useState(false);
  const suggestRef = useRef<HTMLDivElement>(null);

  // Auth State
  const [user, setUser] = useState<{name: string, email: string, photo?: string} | null>(() => {
    const saved = localStorage.getItem('sabah_library_user');
    return saved ? JSON.parse(saved) : null;
  });
  const [showAuthModal, setShowAuthModal] = useState(false);

  // Favorites State
  const [favorites, setFavorites] = useState<Book[]>(() => {
    const saved = localStorage.getItem('sabah_library_favorites');
    return saved ? JSON.parse(saved) : [];
  });

  // Read Books State
  const [readBooks, setReadBooks] = useState<Book[]>(() => {
    const saved = localStorage.getItem('sabah_library_read');
    return saved ? JSON.parse(saved) : [];
  });

  // Last Opened state
  const [lastOpenedBook, setLastOpenedBook] = useState<Book | null>(() => {
    const saved = localStorage.getItem('sabah_library_last_opened');
    return saved ? JSON.parse(saved) : null;
  });

  const [viewMode, setViewMode] = useState<'all' | 'favorites' | 'read'>('all');

  useEffect(() => {
    localStorage.setItem('sabah_library_favorites', JSON.stringify(favorites));
  }, [favorites]);

  useEffect(() => {
    localStorage.setItem('sabah_library_read', JSON.stringify(readBooks));
  }, [readBooks]);

  useEffect(() => {
    if (lastOpenedBook) {
      localStorage.setItem('sabah_library_last_opened', JSON.stringify(lastOpenedBook));
    }
  }, [lastOpenedBook]);

  useEffect(() => {
    if (user) {
      localStorage.setItem('sabah_library_user', JSON.stringify(user));
    } else {
      localStorage.removeItem('sabah_library_user');
    }
  }, [user]);

  // Handle click outside suggestions
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (suggestRef.current && !suggestRef.current.contains(event.target as Node)) {
        setShowSuggestions(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Debounced suggestion fetching
  useEffect(() => {
    const timer = setTimeout(async () => {
      if (searchQuery.trim().length >= 3 && viewMode === 'all') {
        setIsSuggesting(true);
        const results = await fetchSuggestions(searchQuery);
        setSuggestions(results);
        setShowSuggestions(results.length > 0);
        setIsSuggesting(false);
      } else {
        setSuggestions([]);
        setShowSuggestions(false);
      }
    }, 400);

    return () => clearTimeout(timer);
  }, [searchQuery, viewMode]);

  const toggleFavorite = (e: React.MouseEvent, book: Book) => {
    e.stopPropagation();
    setFavorites(prev => {
      const isFav = prev.some(b => b.key === book.key);
      if (isFav) {
        return prev.filter(b => b.key !== book.key);
      } else {
        return [...prev, book];
      }
    });
  };

  const toggleRead = (e: React.MouseEvent, book: Book) => {
    e.stopPropagation();
    setReadBooks(prev => {
      const isRead = prev.some(b => b.key === book.key);
      if (isRead) {
        return prev.filter(b => b.key !== book.key);
      } else {
        return [...prev, book];
      }
    });
  };

  const fetchBooks = useCallback(async (query: string, p: number, categoryQuery?: string) => {
    if (viewMode !== 'all') return;
    setLoading(true);
    
    // Priority: Category Query > Search Query > Default Trending
    const searchTerm = categoryQuery || query.trim() || 'Trending';
    
    try {
      const result = await searchBooks(searchTerm, p);
      if (p === 1) {
        setBooks(result.docs);
      } else {
        setBooks(prev => [...prev, ...result.docs]);
      }
      setTotalFound(result.numFound);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  }, [viewMode]);

  useEffect(() => {
    if (viewMode === 'all') {
      const cat = CATEGORIES.find(c => c.id === activeCategory);
      fetchBooks(searchQuery, 1, cat?.query);
    }
  }, [viewMode, activeCategory]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setShowSuggestions(false);
    setActiveCategory(null); // Clear category on manual search
    if (viewMode !== 'all') setViewMode('all');
    setPage(1);
    fetchBooks(searchQuery, 1);
  };

  const handleCategoryClick = (catId: string) => {
    const newCat = activeCategory === catId ? null : catId;
    setActiveCategory(newCat);
    setSearchQuery(''); // Clear manual search when selecting category
    setPage(1);
    if (viewMode !== 'all') setViewMode('all');
  };

  const handleSuggestionClick = (book: Book) => {
    setSearchQuery(book.title);
    setActiveCategory(null);
    setShowSuggestions(false);
    if (viewMode !== 'all') setViewMode('all');
    setPage(1);
    fetchBooks(book.title, 1);
    setLastOpenedBook(book);
  };

  const handleOpenBook = (key: string) => {
    const book = books.find(b => b.key === key) || 
                 favorites.find(b => b.key === key) || 
                 readBooks.find(b => b.key === key);
    if (book) {
      setLastOpenedBook(book);
    }
    setSelectedBookKey(key);
  };

  const loadMore = () => {
    const nextPage = page + 1;
    setPage(nextPage);
    const cat = CATEGORIES.find(c => c.id === activeCategory);
    fetchBooks(searchQuery, nextPage, cat?.query);
  };

  const getFilteredBooks = () => {
    if (viewMode === 'favorites') return favorites;
    if (viewMode === 'read') return readBooks;
    return books;
  };

  const currentBooks = getFilteredBooks();
  const isBookFavorite = (key: string) => favorites.some(b => b.key === key);
  const isBookRead = (key: string) => readBooks.some(b => b.key === key);
  
  const selectedBookData = 
    books.find(b => b.key === selectedBookKey) || 
    favorites.find(b => b.key === selectedBookKey) || 
    readBooks.find(b => b.key === selectedBookKey);

  const activeCategoryData = CATEGORIES.find(c => c.id === activeCategory);

  return (
    <Layout 
      user={user} 
      onSignInClick={() => setShowAuthModal(true)} 
      onSignOut={() => setUser(null)}
    >
      <section className="relative pt-20 pb-20 px-4 bg-white border-b border-slate-50 z-[30]">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-[600px] bg-gradient-to-b from-indigo-50/50 to-transparent pointer-events-none"></div>
        <div className="max-w-5xl mx-auto text-center relative z-10">
          <h1 className="text-5xl md:text-7xl font-serif font-bold text-slate-900 mb-8 tracking-tight leading-tight">
            {viewMode === 'all' ? (
              <>Discover Millions of <br /> <span className="text-indigo-600">Stories.</span></>
            ) : (
              <>
                {viewMode === 'favorites' ? 'Your Favorite' : "Books You've"}{' '}
                <span className="text-indigo-600">{viewMode === 'read' ? 'Finished.' : 'Stories.'}</span>
              </>
            )}
          </h1>
          
          <div className="flex flex-col items-center space-y-12 mt-12">
            <div className="relative w-full max-w-2xl mx-auto" ref={suggestRef}>
              <form onSubmit={handleSearch} className="relative">
                <input 
                  type="text" 
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onFocus={() => suggestions.length > 0 && setShowSuggestions(true)}
                  placeholder="Search by title, author, or ISBN..."
                  className="w-full pl-14 pr-32 py-5 rounded-2xl bg-white shadow-2xl shadow-indigo-100 border border-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-400 transition-all text-lg font-medium"
                />
                <div className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-400">
                  {isSuggesting ? (
                    <i className="fa-solid fa-circle-notch fa-spin text-xl text-indigo-400"></i>
                  ) : (
                    <i className="fa-solid fa-magnifying-glass text-xl"></i>
                  )}
                </div>
                <button 
                  type="submit"
                  className="absolute right-3 top-1/2 -translate-y-1/2 bg-indigo-600 text-white px-8 py-3 rounded-xl font-bold hover:bg-indigo-700 transition-colors shadow-lg"
                >
                  Search
                </button>
              </form>

              {showSuggestions && (
                <div className="absolute top-full left-0 right-0 mt-2 bg-white rounded-2xl shadow-2xl border border-slate-100 overflow-hidden z-[100] animate-in fade-in slide-in-from-top-2 duration-200">
                  <div className="max-h-[400px] overflow-y-auto">
                    {suggestions.map((book) => (
                      <button
                        key={book.key}
                        onClick={() => handleSuggestionClick(book)}
                        className="w-full flex items-center p-4 hover:bg-slate-50 transition-colors text-left border-b border-slate-50 last:border-0"
                      >
                        <div className="w-10 h-14 bg-slate-100 rounded overflow-hidden mr-4 flex-shrink-0">
                          <img src={getCoverUrl(book.cover_i, 'S')} alt="" className="w-full h-full object-cover" />
                        </div>
                        <div className="flex-grow min-w-0">
                          <div className="text-sm font-bold text-slate-900 truncate">{book.title}</div>
                          <div className="text-xs text-slate-500 truncate">{book.author_name?.join(', ') || 'Unknown Author'}</div>
                        </div>
                        <i className="fa-solid fa-arrow-right text-slate-200 text-xs ml-4"></i>
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Category Explorer */}
            <div className="w-full">
              <p className="text-xs font-bold uppercase tracking-widest text-slate-400 mb-6">Explore by Category</p>
              <div className="flex flex-wrap justify-center gap-4">
                {CATEGORIES.map((cat) => (
                  <button
                    key={cat.id}
                    onClick={() => handleCategoryClick(cat.id)}
                    className={`flex items-center space-x-3 px-6 py-4 rounded-2xl border transition-all duration-300 transform hover:-translate-y-1 ${
                      activeCategory === cat.id 
                      ? 'bg-indigo-600 border-indigo-600 text-white shadow-xl shadow-indigo-200 ring-4 ring-indigo-50' 
                      : 'bg-white border-slate-100 text-slate-600 hover:border-indigo-200 hover:shadow-lg'
                    }`}
                  >
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${activeCategory === cat.id ? 'bg-white/20' : 'bg-slate-50 text-indigo-500'}`}>
                      <i className={`fa-solid ${cat.icon} text-lg`}></i>
                    </div>
                    <span className="font-bold text-sm">{cat.label}</span>
                  </button>
                ))}
              </div>
            </div>

            <div className="flex flex-wrap justify-center items-center gap-4">
              <button 
                onClick={() => { setViewMode('all'); setActiveCategory(null); }}
                className={`px-6 py-3 rounded-full font-bold transition-all ${viewMode === 'all' && !activeCategory ? 'bg-indigo-600 text-white shadow-lg' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}
              >
                Global Search
              </button>
              <button 
                onClick={() => setViewMode('favorites')}
                className={`px-6 py-3 rounded-full font-bold transition-all flex items-center space-x-2 ${viewMode === 'favorites' ? 'bg-rose-500 text-white shadow-lg' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}
              >
                <i className="fa-solid fa-heart"></i>
                <span>Favorites ({favorites.length})</span>
              </button>
              <button 
                onClick={() => setViewMode('read')}
                className={`px-6 py-3 rounded-full font-bold transition-all flex items-center space-x-2 ${viewMode === 'read' ? 'bg-emerald-500 text-white shadow-lg' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}
              >
                <i className="fa-solid fa-check-circle"></i>
                <span>Read ({readBooks.length})</span>
              </button>
            </div>
          </div>
        </div>
      </section>

      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 relative z-[10]">
        
        {/* Read Mode Milestone Card */}
        {viewMode === 'read' && readBooks.length > 0 && (
          <div className="mb-12 animate-in fade-in slide-in-from-top-4 duration-500">
            <div className="bg-gradient-to-br from-emerald-600 to-teal-700 rounded-[2.5rem] p-10 text-white flex flex-col md:flex-row items-center justify-between shadow-2xl border border-emerald-500/20 overflow-hidden relative">
              <div className="absolute top-0 left-0 w-full h-full opacity-10 pointer-events-none">
                <i className="fa-solid fa-book-open text-9xl absolute -bottom-10 -right-10 rotate-12"></i>
                <i className="fa-solid fa-star text-4xl absolute top-10 right-20 animate-pulse"></i>
              </div>
              <div className="text-center md:text-left relative z-10 mb-6 md:mb-0">
                <h3 className="text-4xl md:text-5xl font-serif font-bold mb-2">Amazing Progress!</h3>
                <p className="text-emerald-100 text-lg opacity-90">
                  {readBooks.length === 1 
                    ? "You've finished your first book. Great start!" 
                    : `You have successfully completed ${readBooks.length} books in your library.`}
                </p>
              </div>
              <div className="flex flex-col items-center justify-center bg-white/10 backdrop-blur-md rounded-3xl p-6 border border-white/20 shadow-xl min-w-[200px] relative z-10">
                <div className="w-16 h-16 bg-yellow-400 rounded-2xl flex items-center justify-center text-emerald-900 shadow-lg mb-3">
                  <i className="fa-solid fa-trophy text-2xl"></i>
                </div>
                <div className="text-5xl font-black mb-1 tracking-tighter">{readBooks.length}</div>
                <div className="text-xs font-bold uppercase tracking-widest text-emerald-100">Books Completed</div>
              </div>
            </div>
          </div>
        )}

        {/* Last Opened Spotlight */}
        {viewMode === 'all' && lastOpenedBook && (
          <div className="mb-16 animate-in fade-in slide-in-from-bottom-4 duration-700">
            <div className="bg-gradient-to-r from-slate-900 to-indigo-900 rounded-[2rem] p-8 md:p-12 text-white flex flex-col md:flex-row items-center gap-8 shadow-2xl relative overflow-hidden group">
              <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500/10 rounded-full blur-3xl -mr-32 -mt-32"></div>
              <div className="relative z-10 w-32 md:w-48 flex-shrink-0 shadow-2xl group-hover:scale-105 transition-transform duration-500">
                <img src={getCoverUrl(lastOpenedBook.cover_i, 'M')} alt={lastOpenedBook.title} className="rounded-xl w-full object-cover aspect-[2/3] border border-white/10" />
              </div>
              <div className="relative z-10 text-center md:text-left">
                <div className="inline-flex items-center space-x-2 bg-indigo-500/20 px-4 py-1.5 rounded-full text-indigo-400 text-xs font-bold uppercase tracking-widest mb-6 border border-indigo-500/20">
                  <i className="fa-solid fa-clock-rotate-left"></i>
                  <span>Your Last Read Title</span>
                </div>
                <h3 className="text-3xl md:text-4xl font-serif font-bold mb-3">{lastOpenedBook.title}</h3>
                <p className="text-slate-300 text-lg mb-8 italic">by {lastOpenedBook.author_name?.join(', ') || 'Unknown Author'}</p>
                <button onClick={() => handleOpenBook(lastOpenedBook.key)} className="px-8 py-4 bg-white text-indigo-900 rounded-xl font-bold hover:bg-indigo-50 transition-all shadow-lg transform active:scale-95">
                  Continue Reading
                </button>
              </div>
            </div>
          </div>
        )}

        <div className="flex items-center justify-between mb-10">
          <div>
            <h2 className="text-2xl font-serif font-bold text-slate-900">
              {viewMode === 'favorites' ? 'Saved Favorites' : 
               (viewMode === 'read' ? 'Completed Reading' : 
                (activeCategoryData ? `The Best of ${activeCategoryData.label}` :
                 (searchQuery.trim() ? `Results for "${searchQuery}"` : 'Trending Books')))}
            </h2>
            <p className="text-sm text-slate-500">
              {viewMode === 'all' ? `Found ${totalFound.toLocaleString()} results` : `${currentBooks.length} items in this list`}
            </p>
          </div>
        </div>

        {loading && page === 1 ? (
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-6">
            {[...Array(10)].map((_, i) => (
              <div key={i} className="animate-pulse">
                <div className="bg-slate-200 aspect-[2/3] rounded-2xl mb-4"></div>
                <div className="h-4 bg-slate-200 rounded w-3/4 mb-2"></div>
                <div className="h-4 bg-slate-200 rounded w-1/2"></div>
              </div>
            ))}
          </div>
        ) : (
          <>
            {viewMode !== 'all' && currentBooks.length === 0 ? (
              <div className="text-center py-20 bg-slate-50 rounded-3xl border border-dashed border-slate-200">
                <i className={`fa-regular ${viewMode === 'favorites' ? 'fa-heart' : 'fa-circle-check'} text-6xl text-slate-200 mb-6 block`}></i>
                <h3 className="text-xl font-bold text-slate-900 mb-2">This list is empty</h3>
                <p className="text-slate-500 max-w-sm mx-auto">Start exploring and click the icons on any book to organize your personal library.</p>
                <button onClick={() => { setViewMode('all'); setActiveCategory(null); }} className="mt-8 text-indigo-600 font-bold hover:underline">
                  Go explore books →
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-6">
                {currentBooks.map(book => (
                  <BookCard 
                    key={book.key} 
                    book={book} 
                    onClick={handleOpenBook} 
                    isFavorite={isBookFavorite(book.key)}
                    isRead={isBookRead(book.key)}
                    onToggleFavorite={toggleFavorite}
                    onToggleRead={toggleRead}
                  />
                ))}
              </div>
            )}

            {viewMode === 'all' && totalFound > books.length && (
              <div className="mt-20 text-center">
                <button onClick={loadMore} disabled={loading} className="px-12 py-4 bg-white border border-slate-200 text-slate-700 rounded-2xl font-bold hover:bg-slate-50 hover:border-indigo-200 transition-all shadow-sm flex items-center justify-center mx-auto">
                  {loading && <i className="fa-solid fa-circle-notch fa-spin mr-3 text-indigo-500"></i>}
                  {loading ? 'Fetching More...' : 'Load More Books'}
                </button>
              </div>
            )}
          </>
        )}
      </section>

      <RecommendationSection />

      {selectedBookKey && (
        <BookDetailModal 
          bookKey={selectedBookKey} 
          initialData={selectedBookData}
          onClose={() => setSelectedBookKey(null)} 
          isFavorite={isBookFavorite(selectedBookKey)}
          isRead={isBookRead(selectedBookKey)}
          onToggleFavorite={toggleFavorite}
          onToggleRead={toggleRead}
        />
      )}

      {showAuthModal && (
        <AuthModal 
          onClose={() => setShowAuthModal(false)}
          onLogin={(userData) => setUser(userData)}
        />
      )}
    </Layout>
  );
};

export default App;
